import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class AddEmployee extends JDialog {
    private String[] employeeInfo = new String[] {"", "", "", "", "", ""};

    public AddEmployee() {
        super(new JFrame(), "Добавление сотрудника", true);
        init();
    }
    public AddEmployee(String[] employeeInfo) {
        super(new JFrame(), "Редактирование информации о сотруднике", true);

        this.employeeInfo = employeeInfo;

        init();
    }

    private void init() {
        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private String[] shops;

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // info
        JPanel infoPanel = new JPanel();
        infoPanel.add(new JLabel("Введите информацию о сотруднике"));

        // id
        JPanel idPanel = new JPanel();
        idPanel.setLayout(new BoxLayout(idPanel, BoxLayout.X_AXIS));
        JTextField idField = new JTextField(10);
        idField.setText(employeeInfo[0]);

        idPanel.add(new JLabel("ID сотрудника: "));
        idPanel.add(idField);

        // shop_id
        JPanel shopPanel = new JPanel();
        shopPanel.setLayout(new BoxLayout(shopPanel, BoxLayout.X_AXIS));

        try {
            shops = SQL.getShopId();
        } catch (SQLException exception) {
            System.out.println(exception.getMessage());
        }

        JComboBox shopBox = new JComboBox(shops);
        for (String shop : shops) {
            if (shop.equals(employeeInfo[1]))
                shopBox.setSelectedItem(shop);
        }

        shopPanel.add(new JLabel("ID магазина: "));
        shopPanel.add(shopBox);

        // full_name
        JPanel namePanel = new JPanel();
        namePanel.setLayout(new BoxLayout(namePanel, BoxLayout.X_AXIS));
        JTextField nameField = new JTextField(20);
        nameField.setText(employeeInfo[2]);

        namePanel.add(new JLabel("ФИО: "));
        namePanel.add(nameField);

        // post
        JPanel postPanel = new JPanel();
        postPanel.setLayout(new BoxLayout(postPanel, BoxLayout.X_AXIS));
        JTextField postField = new JTextField(10);
        postField.setText(employeeInfo[3]);

        postPanel.add(new JLabel("Должность: "));
        postPanel.add(postField);

        // salary
        JPanel salaryPanel = new JPanel();
        salaryPanel.setLayout(new BoxLayout(salaryPanel, BoxLayout.X_AXIS));
        JTextField salaryField = new JTextField(10);
        salaryField.setText(employeeInfo[4]);

        salaryPanel.add(new JLabel("Зарплата: "));
        salaryPanel.add(salaryField);

        // login
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.X_AXIS));
        JTextField loginField = new JTextField(10);
        loginField.setText(employeeInfo[5]);

        loginPanel.add(new JLabel("Логин: "));
        loginPanel.add(loginField);

        // password
        JPanel passwordPanel = new JPanel();
        passwordPanel.setLayout(new BoxLayout(passwordPanel, BoxLayout.X_AXIS));
        JPasswordField passwordField = new JPasswordField(10);

        passwordPanel.add(new JLabel("Пароль: "));
        passwordPanel.add(passwordField);

        // button
        String buttonText;
        if (employeeInfo[0].equals(""))
            buttonText = "Добавить сотрудника";
        else buttonText = "Изменить";

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton(buttonText);
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (employeeInfo[0].equals("")) {
                        SQL.addEmployee(idField.getText(),
                                String.valueOf(shopBox.getSelectedItem()),
                                nameField.getText(),
                                postField.getText(),
                                Integer.parseInt(salaryField.getText()),
                                loginField.getText());
                        SQL.createUser(loginField.getText(), passwordField.getText(), "employee");
                        new Notification("Информация о сотруднике успешно добавлена");
                    } else {
                        SQL.editEmployee(idField.getText(),
                                String.valueOf(shopBox.getSelectedItem()),
                                nameField.getText(),
                                postField.getText(),
                                Integer.parseInt(salaryField.getText()),
                                loginField.getText());
                        new Notification("Информация о сотруднике успешно изменена");
                    }
                    dispose();
                } catch (Exception exception) {
                    new Notification(exception.getMessage());
                }
            }
        });
        buttonPanel.add(addButton);

        // Сборка интерфейса
        mainPanel.add(infoPanel);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(idPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(shopPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(namePanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(postPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(salaryPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(loginPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(passwordPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(buttonPanel);

        return mainPanel;
    }
}
