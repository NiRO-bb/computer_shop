import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.SQLException;

public class AddProductCopy extends JDialog {

    private String login, shop_id;

    public AddProductCopy(String login, String shop_id) {
        super(new JFrame(), "Добавление записи о товаре", true);

        this.login = login;
        this.shop_id = shop_id;

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // выбор id товара
        JPanel productPanel = new JPanel();
        productPanel.setLayout(new BoxLayout(productPanel, BoxLayout.X_AXIS));

        String[] shops = null;
        try {
            shops = SQL.getProductId();
            if (!SQL.getCode(login).equals("admin")) // если работает консультант, а не админ
                shop_id = SQL.getShopId(login);
        } catch(SQLException e) {
            System.out.println(e.getMessage());
        }
        JComboBox productBox = new JComboBox(shops);

        productPanel.add(new JLabel("Выберите id товара"));
        productPanel.add(Box.createHorizontalStrut(5));
        productPanel.add(productBox);

        // результат
        JLabel article = new JLabel(shop_id + "_" + String.valueOf(productBox.getSelectedItem()) + "_" + getNumber(productBox));

        productBox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                article.setText(shop_id + "_" + String.valueOf(productBox.getSelectedItem()) + "_" + getNumber(productBox));
            }
        });

        // кнопка
        JButton addButton = new JButton("Добавить запись");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    SQL.addProductCopy(article.getText(), String.valueOf(productBox.getSelectedItem()), shop_id);
                    article.setText(shop_id + "_" + String.valueOf(productBox.getSelectedItem()) + "_" + getNumber(productBox));
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        });

        // сборка интерфейса
        mainPanel.add(productPanel);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(new JLabel("В базу данных будет внесена следующая запись:"));
        mainPanel.add(Box.createVerticalStrut(5));
        mainPanel.add(article);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(addButton);

        return mainPanel;
    }

    private String getNumber(JComboBox productBox) {
        String number = null;

        try {
            number = SQL.checkArticleNumber(shop_id + "_" + String.valueOf(productBox.getSelectedItem()) + "_");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return number;
    }
}