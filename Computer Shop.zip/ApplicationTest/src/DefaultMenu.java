import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class DefaultMenu extends JDialog {

    private String login;

    public DefaultMenu(String login) {
        super(new JFrame(), "Главное меню");
        this.login = login;

        addWindowListener(new WindowAdapter() {
           public void windowClosing(WindowEvent e) {
               dispose();
               System.exit(0);
           }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        // установка отступов
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // welcome message
        JPanel welcomePanel = new JPanel();
        welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.X_AXIS));
        welcomePanel.add(new JLabel("Добро пожаловать, "+login+"!"));

        // панель для кнопок
        JPanel buttonPanelFlow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel buttonPanelGrid = new JPanel(new GridLayout(0, 1, 0, 7));

        JButton exitButton = new JButton("Выйти");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Authorization();
                dispose();
            }
        });

        JButton catalogButton = new JButton("Посмотреть товары");
        catalogButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Catalog(login);
                dispose();
            }
        });

        buttonPanelGrid.add(exitButton);
        buttonPanelGrid.add(catalogButton);

        buttonPanelFlow.add(buttonPanelGrid);

        // Сборка интерфейса
        mainPanel.add(welcomePanel);
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(buttonPanelFlow);

        return mainPanel;
    }
}