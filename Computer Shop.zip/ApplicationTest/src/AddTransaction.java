import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;

public class AddTransaction extends JDialog {
    private String login;

    public AddTransaction(String login) {
        super(new JFrame(), "Новая операция");

        this.login = login;

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private String[] transactionTypes = new String[] {"Продажа", "Поставка", "Возврат"}, products, shops;
    private String type, shopId = null, productId, amount, responsible = null, code;

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // получаем код пользователя - "employee" или "admin"
        try {
            code = SQL.getCode(login);
        } catch (SQLException e) {
            System.out.println(e);
        }

        // выбор типа операции
        JPanel typePanel = new JPanel();
        typePanel.setLayout(new BoxLayout(typePanel, BoxLayout.X_AXIS));

        JComboBox typeBox = new JComboBox(transactionTypes);

        typePanel.add(new JLabel("Выберите тип операции:"));
        typePanel.add(Box.createHorizontalStrut(5));
        typePanel.add(typeBox);

        // выбор магазина
        JPanel shopPanel = new JPanel();
        shopPanel.setLayout(new BoxLayout(shopPanel, BoxLayout.X_AXIS));

        try {
            shops = SQL.getShopId();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        JComboBox shopBox = new JComboBox(shops);

        shopPanel.add(new JLabel("Выбери id магазина:"));
        shopPanel.add(Box.createHorizontalStrut(5));
        shopPanel.add(shopBox);

        // выбор product_id
        JPanel productPanel = new JPanel();
        productPanel.setLayout(new BoxLayout(productPanel, BoxLayout.X_AXIS));

        try {
            products = SQL.getProductId();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        JComboBox productBox = new JComboBox(products);

        productPanel.add(new JLabel("Выберите id товара:"));
        productPanel.add(Box.createHorizontalStrut(5));
        productPanel.add(productBox);

        // количество экземпляров
        JPanel amountPanel = new JPanel();
        amountPanel.setLayout(new BoxLayout(amountPanel, BoxLayout.X_AXIS));

        JTextField amountField = new JTextField(5);

        amountPanel.add(new JLabel("Укажите кол-во экземпляров:"));
        amountPanel.add(Box.createHorizontalStrut(5));
        amountPanel.add(amountField);

        // кнопки
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

        JButton addButton = new JButton("Внести данные об операции");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    // данные
                    type = typeBox.getSelectedItem().toString();
                    responsible = SQL.getEmployeeId(login);
                    productId = productBox.getSelectedItem().toString();
                    amount = amountField.getText();

                    if (code.equals("admin"))
                        shopId = shopBox.getSelectedItem().toString();
                    else
                        shopId = SQL.getShopId(login);

                    // проверка amount на цифры
                    boolean isCorrect = true;

                    for (char c : amount.toCharArray()) {
                        if (!Character.isDigit(c)) {
                            isCorrect = false;
                            break;
                        }
                    }

                    if (isCorrect && Integer.parseInt(amount) > 0) {
                        SQL.addTransaction(type, shopId, productId, amount, responsible);

                        if (typeBox.getSelectedItem().equals(transactionTypes[0])) { // продажа
                            // условно продаем товары с "наименьшим" артикулом
                            ArrayList<String> articles = SQL.getArticleList(shopId, productId);

                            for (int i = 1; i <= Math.min(articles.size(), Integer.parseInt(amount)); i++) {
                                SQL.deleteArticle(articles.get(i - 1));
                            }
                            if (articles.size() < Integer.parseInt(amount)) {
                                new Notification("Число товаров меньше запрашиваемого кол-ва: было продано "+articles.size()+" ед. вместо "+amount+" ед.");
                            }
                        } else { // поставка и возврат
                            for (int i = 1; i <= Integer.parseInt(amount); i++) {
                                SQL.addProductCopy(shopId + "_" + productId + "_" + SQL.checkArticleNumber(shopId + "_" + productId + "_"), productId, shopId);
                            }
                        }

                        new Notification("Данные об операции добавлены");
                    }
                    else
                        new Notification("Поле 'Кол-во экземпляров' должно содержать число большее 0.");
                } catch (SQLException ex) {
                    new Notification("Ошибка: " + ex.getMessage());
                }
            }
        });
        JButton exitButton = new JButton("Назад");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (code.equals("admin"))
                    new AdminMenu(login);
                else if (code.equals("employee"))
                    new EmployeeMenu(login);
                dispose();
            }
        });

        buttonPanel.add(addButton);
        buttonPanel.add(Box.createHorizontalStrut(5));
        buttonPanel.add(exitButton);

        // сборка интерфейса
        mainPanel.add(typePanel);
        mainPanel.add(Box.createVerticalStrut(5));

        if (code.equals("admin")) {
            mainPanel.add(shopPanel);
            mainPanel.add(Box.createVerticalStrut(5));
        }

        mainPanel.add(productPanel);
        mainPanel.add(Box.createVerticalStrut(5));
        mainPanel.add(amountPanel);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(buttonPanel);

        return mainPanel;
    }
}
