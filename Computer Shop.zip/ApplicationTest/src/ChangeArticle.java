import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

public class ChangeArticle extends JDialog {
    private String article, login, shopId;

    public ChangeArticle(String article, String login, String shop_id) {
        super(new JFrame(), "Изменение артикула");

        this.article = article;
        this.login = login;
        this.shopId = shop_id;

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel mainPanel;
    private JTextField articleField;
    private JLabel resultLabel = new JLabel("");

    private JPanel createPanel() {
        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // панель ввода
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.X_AXIS));

        articleField = new JTextField(10);

        inputPanel.add(new JLabel("Введите новый артикул:"));
        inputPanel.add(Box.createHorizontalStrut(10));
        inputPanel.add(articleField);

        // предварительный результат
        String[] oldArticle = article.split("_"); // получаем shop_id + product_id
        String newArticle = oldArticle[0]+"_"+oldArticle[1]+"_"+articleField.getText();
        //resultLabel = new JLabel("Изменить "+article+" на "+newArticle+"?");

        // обновление resultLabel
        articleField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String newArticle = oldArticle[0]+"_"+oldArticle[1]+"_"+articleField.getText();
                setResultLabel(newArticle);
            }
        });

        // кнопки
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

        JButton changeButton = new JButton("Изменить");
        changeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    // обновление значения артикула и выполнение SQL запроса
                    String newArticle = oldArticle[0]+"_"+oldArticle[1]+"_"+articleField.getText();
                    SQL.updateArticle(article, newArticle);

                    // обновление информационной строки
                    article = newArticle;
                    setResultLabel(newArticle);

                    // добавление строки с информацией об успешном действии
                    mainPanel.add(new JLabel("Артикул был успешно изменен на "+article+"!"), 4);
                    mainPanel.add(buttonPanel);
                    pack();
                } catch (SQLException ex) {
                    new Notification("Ошибка: "+ex.getMessage());
                }
            }
        });

        JButton exitButton = new JButton("Назад");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new EditProductCopy(login, shopId);
                dispose();
            }
        });

        buttonPanel.add(changeButton);
        buttonPanel.add(Box.createHorizontalStrut(10));
        buttonPanel.add(exitButton);

        // сборка интерфейса
        mainPanel.add(inputPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(resultLabel);
        mainPanel.add(Box.createVerticalStrut(5));
        mainPanel.add(buttonPanel);

        return mainPanel;
    }

    // при введении артикула появляется надпись
    private void setResultLabel(String newArticle) {
        if (!articleField.getText().isEmpty())
            resultLabel.setText("Изменить "+article+" на "+newArticle+"?");
        else
            resultLabel.setText("");
        pack();
    }
}
