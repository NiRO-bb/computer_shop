import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddShop extends JDialog {
    private String[] shopInfo = new String[] {"", "", "", ""};

    public AddShop() {
        super(new JFrame(), "Добавление магазина", true);

        init();
    }
    public AddShop(String[] shopInfo) {
        super(new JFrame(), "Редактирование магазина", true);

        this.shopInfo = shopInfo;

        init();
    }

    private void init() {
        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // info
        JPanel infoPanel = new JPanel();
        infoPanel.add(new JLabel("Введите данные магазина"));

        // id
        JPanel idPanel = new JPanel();
        idPanel.setLayout(new BoxLayout(idPanel, BoxLayout.X_AXIS));
        JTextField idField = new JTextField(10);
        idField.setText(shopInfo[0]);

        idPanel.add(new JLabel("ID магазина: "));
        idPanel.add(idField);

        // city
        JPanel cityPanel = new JPanel();
        cityPanel.setLayout(new BoxLayout(cityPanel, BoxLayout.X_AXIS));
        JTextField cityField = new JTextField(20);
        cityField.setText(shopInfo[1]);

        cityPanel.add(new JLabel("Город: "));
        cityPanel.add(cityField);

        // street
        JPanel streetPanel = new JPanel();
        streetPanel.setLayout(new BoxLayout(streetPanel, BoxLayout.X_AXIS));
        JTextField streetField = new JTextField(20);
        streetField.setText(shopInfo[2]);

        streetPanel.add(new JLabel("Улица: "));
        streetPanel.add(streetField);

        // building
        JPanel buildingPanel = new JPanel();
        buildingPanel.setLayout(new BoxLayout(buildingPanel, BoxLayout.X_AXIS));
        JTextField buildingField = new JTextField(10);
        buildingField.setText(shopInfo[3]);

        buildingPanel.add(new JLabel("Номер дома: "));
        buildingPanel.add(buildingField);

        // button
        String buttonText;
        if (shopInfo[0].equals(""))
            buttonText = "Добавить магазин";
        else buttonText = "Изменить";

        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton(buttonText);
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (shopInfo[0].equals("")) {
                        SQL.addShop(idField.getText(),
                                cityField.getText(),
                                streetField.getText(),
                                Integer.parseInt(buildingField.getText()));
                        new Notification("Магазин успешно добавлен");
                    } else {
                        SQL.editShop(idField.getText(),
                                cityField.getText(),
                                streetField.getText(),
                                Integer.parseInt(buildingField.getText()));
                        new Notification("Информация о магазине успешно изменена");
                    }

                    dispose();
                } catch (Exception exception) {
                    new Notification(exception.getMessage());
                }
            }
        });
        buttonPanel.add(addButton);

        // Сборка интерфейса
        mainPanel.add(infoPanel);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(idPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(cityPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(streetPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(buildingPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(buttonPanel);

        return mainPanel;
    }
}
