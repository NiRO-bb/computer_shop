import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Registration extends JDialog {

    public Registration () {
        super(new JFrame(), "Регистрация");
        
        addWindowListener(new WindowAdapter() {
            public void windowClosing (WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });
        
        getContentPane().add(createPanel());
        pack();
        
        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // info label
        JPanel infoPanel = new JPanel();
        JLabel infoLabel = new JLabel("Укажите логин и пароль для вашей записи");
        infoPanel.add(infoLabel);

        // login
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.X_AXIS));

        JTextField loginField = new JTextField(30);

        loginPanel.add(new JLabel("Логин:"));
        loginPanel.add(Box.createHorizontalStrut(15));
        loginPanel.add(loginField);

        // password
        JPanel passwordPanel = new JPanel();
        passwordPanel.setLayout(new BoxLayout(passwordPanel, BoxLayout.X_AXIS));

        JPasswordField passwordField = new JPasswordField(30);

        passwordPanel.add(new JLabel("Пароль:"));
        passwordPanel.add(Box.createHorizontalStrut(15));
        passwordPanel.add(passwordField);

        // password confirmation
        JPanel passwordConfirmPanel = new JPanel();
        passwordConfirmPanel.setLayout(new BoxLayout(passwordConfirmPanel, BoxLayout.X_AXIS));

        JPasswordField passwordConfirmField = new JPasswordField(30);

        passwordConfirmPanel.add(new JLabel("Подтвердите пароль:"));
        passwordConfirmPanel.add(Box.createHorizontalStrut(15));
        passwordConfirmPanel.add(passwordConfirmField);

        // buttons
        JPanel btnPanelFlow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel btnPanelGrid = new JPanel(new GridLayout(1, 0, 10, 0));

        JButton exitButton = new JButton("Назад");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Authorization();
                dispose();
            }
        });

        JButton createButton = new JButton("Создать");
        createButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    // несовпадает пароль
                    if (!passwordField.getText().equals(passwordConfirmField.getText())) {
                        infoLabel.setText("Введённые пароли не совпадают! Попробуйте еще раз");
                        passwordField.setText("");
                        passwordConfirmField.setText("");
                    }
                    // логин занят
                    else if (SQL.isLoginExist(loginField.getText())) {
                        infoLabel.setText("Пользователь с таким логином уже существует!");
                        passwordField.setText("");
                        passwordConfirmField.setText("");
                    }
                    // пустое поле пароля
                    else if (passwordField.getText().equals("")) {
                        infoLabel.setText("Введите пароль!");
                        passwordField.setText("");
                        passwordConfirmField.setText("");
                    }
                    // все ок
                    else {
                        // проверка кода
                        SQL.createUser(loginField.getText(), passwordField.getText(), "none");

                        // проверка кода доступа
                        if (SQL.checkCode(loginField.getText()).equals("admin")) {
                            // открываем меню для админов
                            new AdminMenu(loginField.getText());
                        } else if (SQL.checkCode(loginField.getText()).equals("employee")) {
                            // открываем меню для сотрудников
                            new EmployeeMenu(loginField.getText());
                        } else {
                            // открываем меню для клиентоа
                            new DefaultMenu(loginField.getText());
                        }

                        dispose();
                    }
                } catch (SQLException exception) {
                    System.out.println(exception.getMessage());
                }
            }
        });

        btnPanelGrid.add(exitButton);
        btnPanelGrid.add(createButton);

        btnPanelFlow.add(btnPanelGrid);

        // Сборка интерфейса
        mainPanel.add(infoPanel);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(loginPanel);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(passwordPanel);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(passwordConfirmPanel);
        mainPanel.add(Box.createVerticalStrut(50));
        mainPanel.add(btnPanelFlow);

        return mainPanel;
    }
}