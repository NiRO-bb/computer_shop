import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

public class Authorization extends JDialog {

    public Authorization() {
        super(new JFrame(), "Авторизация");

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // панель для надписи и текстового поля (ЛОГИН)
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.X_AXIS));

        JTextField loginField = new JTextField(30);

        loginPanel.add(new JLabel("Логин:"));
        loginPanel.add(Box.createHorizontalStrut(15));
        loginPanel.add(loginField);

        // панель для надписи и текстового поля (ПАРОЛЬ)
        JPanel passwordPanel = new JPanel();
        passwordPanel.setLayout(new BoxLayout(passwordPanel, BoxLayout.X_AXIS));

        JPasswordField passwordField = new JPasswordField(20);

        passwordPanel.add(new JLabel("Пароль:"));
        passwordPanel.add(Box.createHorizontalStrut(15));
        passwordPanel.add(passwordField);

        // панель для надписи
        JPanel infoPanel = new JPanel();
        JLabel infoLabel = new JLabel("Введите данные вашего аккаунта");
        infoPanel.add(infoLabel);

        // панель для кнопки
        JPanel buttonPanelFlow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel buttonPanelGrid = new JPanel(new GridLayout(1, 0, 10, 0));

        JButton enterButton = new JButton("Войти");
        enterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (SQL.checkUsers(loginField.getText(), passwordField.getText())) {
                        // проверка кода доступа
                        if (SQL.checkCode(loginField.getText()).equals("admin")) {
                            // открываем меню для админов
                            new AdminMenu(loginField.getText());
                        } else if (SQL.checkCode(loginField.getText()).equals("employee")) {
                            // открываем меню для сотрудников
                            new EmployeeMenu(loginField.getText());
                        } else {
                            // открываем меню для клиентоа
                            new DefaultMenu(loginField.getText());
                        }

                        dispose();
                    }
                    else {
                        infoLabel.setText("Неверный логин или пароль");
                        passwordField.setText("");
                    }
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        });

        JButton regButton = new JButton("Зарегистрироваться");
        regButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Registration();
                dispose();
            }
        });

        buttonPanelGrid.add(enterButton);
        buttonPanelGrid.add(regButton);
        buttonPanelFlow.add(buttonPanelGrid);

        // сборка интерфейса
        mainPanel.add(loginPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(passwordPanel);
        mainPanel.add(Box.createVerticalStrut(50));
        mainPanel.add(infoPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(buttonPanelFlow);

        return mainPanel;
    }
}