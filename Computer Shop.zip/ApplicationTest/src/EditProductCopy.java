import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EditProductCopy extends JDialog {
    private String login, shop_id;

    public EditProductCopy (String login) {
        super(new JFrame(), "Каталог товаров");

        this.login = login;

        init();
    }

    public EditProductCopy (String login, String shop_id) {
        super(new JFrame(), "Каталог товаров");

        this.login = login;
        this.shop_id = shop_id;

        init();
    }

    private void init() {
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }


    private JPanel mainPanel, articlePanel;
    private JTextField searchField;

    private JPanel createPanel() {
        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // получаем номер магазина
        try {
            if (!SQL.getCode(login).equals("admin"))
                shop_id = SQL.getShopId(login);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        // строка поиска
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new BoxLayout(searchPanel, BoxLayout.X_AXIS));

        searchField = new JTextField(30);
        searchField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search();
            }
        });

        JButton searchButton = new JButton("Поиск");
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search();
            }
        });

        searchPanel.add(new JLabel("Введите артикул:"));
        searchPanel.add(Box.createHorizontalStrut(5));
        searchPanel.add(searchField);
        searchPanel.add(Box.createHorizontalStrut(10));
        searchPanel.add(searchButton);

        // поле для списка товаров + кнопка для каждого товара
        articlePanel = new JPanel();
        articlePanel.setLayout(new BoxLayout(articlePanel, BoxLayout.Y_AXIS));

        try {
            ArrayList<String> articles = SQL.getArticleList(shop_id);

            for (String article : articles) {
                addLine(article, articlePanel);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        // сборка интерфейса
        mainPanel.add(searchPanel);
        mainPanel.add(Box.createVerticalStrut(10));

        JScrollPane scrollPane = new JScrollPane(articlePanel);

        scrollPane.setPreferredSize(new Dimension(400, 500));
        //scrollPane.setMaximumSize(new Dimension(400, 700));

        mainPanel.add(scrollPane);

        addExitButton(mainPanel);

        return mainPanel;
    }

    private void search() {
        // реализация поиска
        Pattern pattern = Pattern.compile(Pattern.quote(searchField.getText()), Pattern.CASE_INSENSITIVE);
        Matcher matcher;

        articlePanel.removeAll(); // удаление результатов прошлого запроса

        try {
            ArrayList<String> articles = SQL.getArticleList(shop_id);

            for (String article : articles) {
                matcher = pattern.matcher(article);

                // в случае соответствия
                if (matcher.find())
                    addLine(article, articlePanel);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        pack(); // обновляем содержимое mainPanel
    }

    private void addLine(String article, JPanel panel) {
        JPanel linePanel = new JPanel(new GridLayout(1, 1));

        JLabel label = new JLabel("Арт. "+article);
        JButton deleteButton = new JButton("Удалить");
        JButton changeButton = new JButton("Изменить");

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

        buttonPanel.add(deleteButton);
        buttonPanel.add(changeButton);

        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    SQL.deleteArticle(article);
                    linePanel.remove(label);
                    linePanel.remove(buttonPanel);
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
                pack();
            }
        });

        changeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ChangeArticle(article ,login, shop_id);
                dispose();
            }
        });

        linePanel.add(label);

        linePanel.add(buttonPanel);
        panel.add(linePanel);
    }

    private void addExitButton(JPanel panel) {
        JButton exitButton = new JButton("Назад");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String code = null;
                try {
                    code = SQL.getCode(login);
                } catch (SQLException exception) {
                    System.out.println(exception.getMessage());
                }

                if (code.equals("employee"))
                    new EmployeeMenu(login);
                else if (code.equals("admin"))
                    new ShopMenu(login, shop_id);
                dispose();
            }
        });

        panel.add(Box.createVerticalStrut(10));
        panel.add(exitButton);
    }
}
