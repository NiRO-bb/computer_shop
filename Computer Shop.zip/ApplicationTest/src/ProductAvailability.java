import javax.swing.*;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProductAvailability extends JDialog {
    public ProductAvailability (JFrame frame, String[] product) {
        super(frame, "Подробнее о товаре", true);

        getContentPane().add(createPanel(product));
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel (String[] product) {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // тип, модель, изготовитель и цена + (описание)
        mainPanel.add(new JLabel("Тип: " + product[1]));
        mainPanel.add(Box.createVerticalStrut(5));

        mainPanel.add(new JLabel("Модель: " + product[2]));
        mainPanel.add(Box.createVerticalStrut(5));

        mainPanel.add(new JLabel("Производитель: " + product[3]));
        mainPanel.add(Box.createVerticalStrut(5));

        mainPanel.add(new JLabel("Цена: " + product[4]));
        mainPanel.add(Box.createVerticalStrut(20));

        mainPanel.add(new JLabel("Наличие в магазинах"));
        mainPanel.add(Box.createVerticalStrut(10));

        // вызов метода SQL и добавление информации о наличии товара в магазинах
        // появляется список магазинов, в которых есть выбранный товар

        try {
            ArrayList<String> shops = SQL.getShopList(product[0]);

            int num = 1;
            for (String shop : shops) {
                mainPanel.add(new JLabel(num++ + ". " + shop));
                mainPanel.add(Box.createVerticalStrut(5));
            }

            if (shops.size() == 0) {
                mainPanel.add(new JLabel("Товар отсутствует"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return mainPanel;
    }
}
