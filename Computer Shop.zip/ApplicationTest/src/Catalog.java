import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Catalog extends JDialog {

    private String login;

    public Catalog (String login) {
        super(new JFrame(), "Каталог товаров");

        this.login = login;

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel mainPanel, productPanel;
    private JTextField searchField;

    private JPanel createPanel() {
        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // строка поиска
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new BoxLayout(searchPanel, BoxLayout.X_AXIS));

        searchField = new JTextField(30);
        searchField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search(); // поиск
            }
        });

        JButton searchButton = new JButton("Поиск");
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search(); // поиск
            }
        });

        searchPanel.add(new JLabel("Введите название товара:"));
        searchPanel.add(Box.createHorizontalStrut(5));
        searchPanel.add(searchField);
        searchPanel.add(Box.createHorizontalStrut(10));
        searchPanel.add(searchButton);

        // поле для списка товаров + кнопка для каждого товара
        productPanel = new JPanel();
        productPanel.setLayout(new BoxLayout(productPanel, BoxLayout.Y_AXIS));

        try {
            ArrayList<String[]> products = SQL.getProductInfo();
            int num = 1;

            for (String[] product : products) {
                addProductLine(num++, product, productPanel);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        // сборка интерфейса
        mainPanel.add(searchPanel);
        mainPanel.add(Box.createVerticalStrut(10));

        JScrollPane scrollPane = new JScrollPane(productPanel);
        scrollPane.setPreferredSize(new Dimension(500, 700));
        mainPanel.add(scrollPane);

        addExitButton(mainPanel);

        return mainPanel;
    }

    // поиск
    private void search() {
        // реализация поиска
        Pattern pattern = Pattern.compile(searchField.getText().toLowerCase(), Pattern.CASE_INSENSITIVE);
        Matcher matcher;

        productPanel.removeAll(); // удаление результатов прошлого запроса

        try {
            ArrayList<String[]> products = SQL.getProductInfo();
            int num = 1;

            for (String[] product : products) {
                matcher = pattern.matcher((product[1]+" "+product[2]+" - "+product[4]).toLowerCase());

                // в случае соответствия
                if (matcher.find())
                    addProductLine(num++, product, productPanel);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        pack(); // обновляем содержимое mainPanel
    }

    private void addProductLine(int num, String[] product, JPanel panel) {
        JPanel productLinePanel = new JPanel(new GridLayout(0, 1, 10, 0));

        String description = product[1]+" "+product[2]+" - "+product[4];
        productLinePanel.add(new JLabel(num++ + ". " + description));

        // buttons
        JButton removeButton = new JButton("Удалить");
        JButton editButton = new JButton("Изменить");
        JButton productButton = new JButton("Подробнее");

        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    SQL.removeProduct(Integer.parseInt(product[0]));
                    new Notification("Товар был удален из каталога");

                    productLinePanel.removeAll();
                    pack();
                } catch (SQLException exception) {
                    System.out.println(exception.getMessage());
                }
            }
        });

        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddProduct(product);
            }
        });

        productButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ProductAvailability(new JFrame(), product);
            }
        });

        // сборка строки
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

        try {
            if (SQL.getCode(login).equals("admin")) {
                buttonPanel.add(removeButton);
                buttonPanel.add(editButton);
            }
        } catch (SQLException exception) {
            System.out.println(exception.getMessage());
        }

        buttonPanel.add(productButton);

        productLinePanel.add(buttonPanel);

        panel.add(productLinePanel);
    }

    private void addExitButton(JPanel panel) {
        JButton exitButton = new JButton("Назад");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String code = null;
                try {
                    code = SQL.getCode(login);
                } catch (SQLException exception) {
                    System.out.println(exception.getMessage());
                }

                if (code.equals("none")) // 1. клиент
                    new DefaultMenu(login);
                else if (code.equals("employee")) // 2. сотрудник
                    new EmployeeMenu(login);
                else if (code.equals("admin")) // 3. админ
                    new AdminMenu(login);

                dispose();
            }
        });

        panel.add(Box.createVerticalStrut(10));
        panel.add(exitButton);
    }
}