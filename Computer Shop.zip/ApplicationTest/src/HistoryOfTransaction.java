import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HistoryOfTransaction extends JDialog {
    private String login;

    public HistoryOfTransaction(String login) {
        super(new JFrame(), "История операций");

        this.login = login;

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JTextField searchField;
    private JPanel transactionPanel;
    private ArrayList<String[]> transactions;
    private String code, shopId;

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // получаем код пользователя и номер магазина
        try {
            code = SQL.getCode(login);
            shopId = SQL.getShopId(login);
        } catch (SQLException exception) {
            System.out.println(exception.getMessage());
        }

        // поиск
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new BoxLayout(searchPanel, BoxLayout.X_AXIS));

        searchField = new JTextField(30);
        searchField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search();
            }
        });

        JButton searchButton = new JButton("Поиск");
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search();
            }
        });

        searchPanel.add(new JLabel("Введите данные операции:"));
        searchPanel.add(Box.createHorizontalStrut(5));
        searchPanel.add(searchField);
        searchPanel.add(Box.createHorizontalStrut(10));
        searchPanel.add(searchButton);

        // операции
        transactionPanel = new JPanel();
        transactionPanel.setLayout(new GridLayout(0, 1, 10, 5));

        try {
            transactions = SQL.getTransactionList();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        int num = 1;
        for (String[] transaction : transactions) {
            JLabel transactionLabel = null;
            String label = null;
            if (!code.equals("admin")) {
                if (transaction[2].equals(shopId)) {
                    label = "Тип: " + transaction[1] + ", ID товара: " + transaction[3] + " в кол-ве " + transaction[4] + " ед.; Ответственный - " + transaction[5];
                    transactionLabel = new JLabel(num++ + ". " + label);
                    transactionPanel.add(transactionLabel);
                }
            } else {
                label = "Тип: " + transaction[1] + ", ID магазина: " + transaction[2] + ", ID товара: " + transaction[3] + " в кол-ве " + transaction[4] + " ед.; Ответственный - " + transaction[5];
                transactionLabel = new JLabel(num++ + ". " + label);
                transactionPanel.add(transactionLabel);
            }

            if (code.equals("admin")) {
                JPanel buttonPanel = new JPanel();
                buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

                addButton(buttonPanel, Integer.parseInt(transaction[0]));
                transactionPanel.add(buttonPanel);
            }

        }
        // кнопка
        JButton exitButton = new JButton("Назад");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (code.equals("admin"))
                    new AdminMenu(login);
                else if (code.equals("employee"))
                    new EmployeeMenu(login);
                dispose();
            }
        });

        mainPanel.add(searchPanel);
        mainPanel.add(Box.createVerticalStrut(10));

        JScrollPane productScrollPane = new JScrollPane(transactionPanel);
        productScrollPane.setMaximumSize(new Dimension(500, 100));

        mainPanel.add(productScrollPane);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(exitButton);

        return mainPanel;
    }

    private void search() {
        // реализация поиска
        Pattern pattern = Pattern.compile(searchField.getText().toLowerCase(), Pattern.CASE_INSENSITIVE);
        Matcher matcher = null;

        transactionPanel.removeAll(); // удаление результатов прошлого запроса

        try {
            transactions = SQL.getTransactionList();
            int num = 1;

            for (String[] transaction : transactions) {
                boolean isAdded = false;
                String label = null;
                if (!code.equals("admin")) {
                    if (transaction[2].equals(shopId)) {
                        label = "Тип: " + transaction[1] + ", ID товара: " + transaction[3] + " в кол-ве " + transaction[4] + " ед.; Ответственный - " + transaction[5];
                        isAdded = true;
                        matcher = pattern.matcher(label.toLowerCase());
                    }
                } else {
                    label = "Тип: " + transaction[1] + ", ID магазина: " + transaction[2] + ", ID товара: " + transaction[3] + " в кол-ве " + transaction[4] + " ед.; Ответственный - " + transaction[5];
                    isAdded = true;
                    matcher = pattern.matcher(label.toLowerCase());
                }

                // в случае соответствия
                if (matcher.find() && isAdded) {
                    transactionPanel.add(new JLabel(num++ + ". " + label));

                    if (code.equals("admin")) {
                        JPanel buttonPanel = new JPanel();
                        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

                        addButton(buttonPanel, Integer.parseInt(transaction[0]));
                        transactionPanel.add(buttonPanel);
                    }
                }
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        pack(); // обновляем содержимое mainPanel
    }

    private void addButton(JPanel panel, int id) {

        JButton removeButton = new JButton("Удалить");
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    SQL.removeTransaction(id);
                    search();
                    new Notification("Данные об операции были успешно удалены");
                } catch (SQLException exception) {
                    new Notification(exception.getMessage());
                }
            }
        });

        panel.add(removeButton);
    }
}
