import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmployeeList extends JDialog {
    String login;

    public EmployeeList(String login) {
        super(new JFrame(), "Список сотрудников");
        this.login = login;

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JTextField searchField;
    private JPanel productPanel;

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // строка поиска
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new BoxLayout(searchPanel, BoxLayout.X_AXIS));

        JLabel searchLabel = new JLabel("Введите имя сотрудника:");
        searchPanel.add(searchLabel);
        searchPanel.add(Box.createHorizontalStrut(5));

        searchField = new JTextField(30);
        searchField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search();
            }
        });
        searchPanel.add(searchField);
        searchPanel.add(Box.createHorizontalStrut(10));

        JButton searchButton = new JButton("Поиск");
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search();
            }
        });
        searchPanel.add(searchButton);

        // поле для списка товаров + кнопка для каждого товара
        productPanel = new JPanel();
        productPanel.setLayout(new BoxLayout(productPanel, BoxLayout.Y_AXIS));

        try {
            ArrayList<String[]> employees = SQL.getEmployeeInfo();
            int num = 1;

            for (String[] employee : employees) {
                addProductLine(num++, employee, productPanel);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        // сборка интерфейса
        mainPanel.add(searchPanel);
        mainPanel.add(Box.createVerticalStrut(10));

        JScrollPane productScrollPane = new JScrollPane(productPanel);
        productScrollPane.setPreferredSize(new Dimension(700, 500));
        mainPanel.add(productScrollPane);

        addExitButton(mainPanel);

        return mainPanel;
    }

    // поиск
    private void search() {
        // реализация поиска
        Pattern pattern = Pattern.compile(searchField.getText().toLowerCase(), Pattern.CASE_INSENSITIVE);
        Matcher matcher;

        productPanel.removeAll(); // удаление результатов прошлого запроса

        try {
            ArrayList<String[]> employees = SQL.getEmployeeInfo();
            int num = 1;

            for (String[] employee : employees) {
                matcher = pattern.matcher((employee[2]+
                        ", магазин - "+employee[1] +
                        ", должность - "+employee[3] +
                        ", зарплата - "+employee[4]).toLowerCase());

                // в случае соответствия
                if (matcher.find())
                    addProductLine(num++, employee, productPanel);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        pack(); // обновляем содержимое mainPanel
    }

    private void addProductLine(int num, String[] employee, JPanel panel) {
        JPanel productLinePanel = new JPanel(new GridLayout(0, 1, 0, 5));

        String description = employee[2]+
                ", магазин - "+employee[1] +
                ", должность - "+employee[3] +
                ", зарплата - "+employee[4];

        productLinePanel.add(new JLabel(num++ + ". " + description));

        JButton removeButton = new JButton("Удалить");
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    SQL.removeEmployee(employee[0]);
                    new Notification("Информация о сотруднике была удалена");

                    panel.remove(productLinePanel);
                    pack();
                } catch (SQLException exception) {
                    System.out.println(exception.getMessage());
                }
            }
        });

        JButton editButton = new JButton("Изменить");
        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddEmployee(employee);
            }
        });

        // buttonPanel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

        buttonPanel.add(removeButton);
        buttonPanel.add(Box.createHorizontalStrut(10));
        buttonPanel.add(editButton);

        productLinePanel.add(buttonPanel);
        //productLinePanel.add(Box.createHorizontalGlue());

        panel.add(productLinePanel);
    }

    private void addExitButton(JPanel panel) {
        JButton exitButton = new JButton("Назад");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminMenu(login);
                dispose();
            }
        });

        panel.add(Box.createVerticalStrut(10));
        panel.add(exitButton);
    }
}
