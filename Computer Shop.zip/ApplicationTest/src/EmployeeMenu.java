import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class EmployeeMenu extends JDialog {

    private String login;

    public EmployeeMenu(String login) {
        super(new JFrame(), "Главное меню");

        this.login = login;

        addWindowListener(new WindowAdapter() {
           public void windowClosing(WindowEvent e) {
               dispose();
               System.exit(0);
           }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // welcome message
        JPanel welcomePanel = new JPanel();
        welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.X_AXIS));

        JLabel welcomeLabel = new JLabel("Добро пожаловать, "+login+"!");
        welcomePanel.add(welcomeLabel);

        // панель для кнопок
        JPanel buttonPanelFlow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel buttonPanelGrid = new JPanel(new GridLayout(0, 1));

        JButton exitButton = new JButton("Выйти");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Authorization();
                dispose();
            }
        });

        // ассортимент
        JButton catalogButton = new JButton("Ассортимент");
        catalogButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Catalog(login);
                dispose();
            }
        });

        JButton addCopy = new JButton("Добавить запись");
        addCopy.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddProductCopy(login, null);
            }
        });
        JButton editCopy = new JButton("Изменить запись");
        editCopy.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new EditProductCopy(login);
                dispose();
            }
        });

        JButton transactionAdd = new JButton("Новая операция");
        transactionAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddTransaction(login);
                dispose();
            }
        });
        JButton transactionHistory = new JButton("История операций");
        transactionHistory.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new HistoryOfTransaction(login);
                dispose();
            }
        });

        buttonPanelGrid.add(new JLabel("Вернуться в меню авторизации:"));
        buttonPanelGrid.add(exitButton);
        buttonPanelGrid.add(Box.createVerticalStrut(5));

        buttonPanelGrid.add(new JLabel("Ассортимент:"));
        buttonPanelGrid.add(catalogButton);
        buttonPanelGrid.add(Box.createVerticalStrut(5));

        buttonPanelGrid.add(new JLabel("Работа с товаром:"));
        buttonPanelGrid.add(addCopy);
        buttonPanelGrid.add(editCopy);
        buttonPanelGrid.add(Box.createVerticalStrut(5));

        buttonPanelGrid.add(new JLabel("Операции:"));
        buttonPanelGrid.add(transactionAdd);
        buttonPanelGrid.add(transactionHistory);

        buttonPanelFlow.add(buttonPanelGrid);

        // Сборка интерфейса
        mainPanel.add(welcomePanel);
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(buttonPanelFlow);

        return mainPanel;
    }
}