public class Main {
    public static void main(String[] args) {
        new Authorization();
        //new AdminMenu("FominMF");
    }
}