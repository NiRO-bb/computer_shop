import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ShopList extends JDialog {
    private String login;

    public ShopList(String login) {
        super(new JFrame(), "Список магазинов");
        this.login = login;

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JTextField searchField;
    private JPanel productPanel;

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // строка поиска
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new BoxLayout(searchPanel, BoxLayout.X_AXIS));

        searchField = new JTextField(30);
        searchField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search();
            }
        });

        JButton searchButton = new JButton("Поиск");
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                search();
            }
        });

        searchPanel.add(new JLabel("Введите адрес магазина:"));
        searchPanel.add(Box.createHorizontalStrut(5));
        searchPanel.add(searchField);
        searchPanel.add(Box.createHorizontalStrut(10));
        searchPanel.add(searchButton);

        // поле для списка товаров + кнопка для каждого товара
        productPanel = new JPanel();
        productPanel.setLayout(new BoxLayout(productPanel, BoxLayout.Y_AXIS));

        try {
            ArrayList<String[]> shops = SQL.getShopInfo();
            int num = 1;

            for (String[] shop : shops) {
                addProductLine(num++, shop, productPanel);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        // сборка интерфейса
        mainPanel.add(searchPanel);
        mainPanel.add(Box.createVerticalStrut(10));

        JScrollPane scrollPane = new JScrollPane(productPanel);
        scrollPane.setMaximumSize(new Dimension(500, 500));
        mainPanel.add(scrollPane);

        addExitButton(mainPanel);

        return mainPanel;
    }

    // поиск
    private void search() {
        // реализация поиска
        Pattern pattern = Pattern.compile(searchField.getText().toLowerCase(), Pattern.CASE_INSENSITIVE);
        Matcher matcher;

        productPanel.removeAll(); // удаление результатов прошлого запроса

        try {
            ArrayList<String[]> shops = SQL.getShopInfo();
            int num = 1;

            for (String[] shop : shops) {
                matcher = pattern.matcher(("г. "+shop[1]+", ул. "+shop[2]+", д. "+shop[3]).toLowerCase());

                // в случае соответствия
                if (matcher.find())
                    addProductLine(num++, shop, productPanel);
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        pack(); // обновляем содержимое mainPanel
    }

    private void addProductLine(int num, String[] shop, JPanel panel) {
        JPanel productLinePanel = new JPanel(new GridLayout(0, 1, 10, 0));

        String description = "г. "+shop[1]+", ул. "+shop[2]+", д. "+shop[3];
        productLinePanel.add(new JLabel(num++ + ". " + description));

        JButton removeButton = new JButton("Удалить");
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    SQL.removeShop(shop[0]);
                    new Notification("Магазин был удален из списка");

                    productLinePanel.removeAll();
                    pack();
                } catch (SQLException exception) {
                    System.out.println(exception.getMessage());
                }
            }
        });

        JButton editButton = new JButton("Изменить");
        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddShop(shop);
            }
        });

        JButton productButton = new JButton("Открыть каталог");
        productButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ShopMenu(login, shop[0]);
                dispose();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

        buttonPanel.add(removeButton);
        buttonPanel.add(Box.createHorizontalStrut(10));
        buttonPanel.add(editButton);
        buttonPanel.add(Box.createHorizontalStrut(10));
        buttonPanel.add(productButton);

        productLinePanel.add(buttonPanel);
        panel.add(productLinePanel);
    }

    private void addExitButton(JPanel panel) {
        JButton exitButton = new JButton("Назад");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AdminMenu(login);
                dispose();
            }
        });

        panel.add(Box.createVerticalStrut(10));
        panel.add(exitButton);
    }
}
