import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class AdminMenu extends JDialog {

    private String login;

    public AdminMenu(String login) {
        super(new JFrame(), "Главное меню");

        this.login = login;

        addWindowListener(new WindowAdapter() {
           public void windowClosing(WindowEvent e) {
               dispose();
               System.exit(0);
           }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        // установка отступов
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // welcome message
        JPanel welcomePanel = new JPanel();
        welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.X_AXIS));

        JLabel welcomeLabel = new JLabel("Добро пожаловать, "+login+"!");
        welcomePanel.add(welcomeLabel);

        // панель для кнопок
        JPanel buttonPanelFlow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel buttonPanelGrid = new JPanel(new GridLayout(0, 1));

        JButton exitButton = new JButton("Выйти");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Authorization();
                dispose();
            }
        });

        // Товары
        JButton addProductButton = new JButton("Добавить товар");
        addProductButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddProduct();
            }
        });

        JButton productListButton = new JButton("Список товаров");
        productListButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Catalog(login);
                dispose();
            }
        });

        // Магазины
        JButton addShopButton = new JButton("Добавить магазин");
        addShopButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddShop();
            }
        });

        JButton shopListButton = new JButton("Список магазинов");
        shopListButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ShopList(login);
                dispose();
            }
        });

        // Операции
        JButton addTransactionButton = new JButton("Новая операция");
        addTransactionButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddTransaction(login);
                dispose();
            }
        });

        JButton transactionHistoryButton = new JButton("История операций");
        transactionHistoryButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new HistoryOfTransaction(login);
                dispose();
            }
        });

        // Сотрудники
        JButton addEmployeeButton = new JButton("Новый сотрудник");
        addEmployeeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddEmployee();
            }
        });

        JButton employeeListButton = new JButton("Список сотрудников");
        employeeListButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new EmployeeList(login);
                dispose();
            }
        });

        // Сборка панели
        buttonPanelGrid.add(new JLabel("Вернуться в меню авторизации:"));
        buttonPanelGrid.add(exitButton);
        buttonPanelGrid.add(Box.createHorizontalStrut(5));

        buttonPanelGrid.add(new JLabel("Товары:"));
        buttonPanelGrid.add(addProductButton);
        buttonPanelGrid.add(productListButton);
        buttonPanelGrid.add(Box.createHorizontalStrut(5));

        buttonPanelGrid.add(new JLabel("Магазины:"));
        buttonPanelGrid.add(addShopButton);
        buttonPanelGrid.add(shopListButton);
        buttonPanelGrid.add(Box.createHorizontalStrut(5));

        buttonPanelGrid.add(new JLabel("Операции:"));
        buttonPanelGrid.add(addTransactionButton);
        buttonPanelGrid.add(transactionHistoryButton);
        buttonPanelGrid.add(Box.createHorizontalStrut(5));

        buttonPanelGrid.add(new JLabel("Сотрудники:"));
        buttonPanelGrid.add(addEmployeeButton);
        buttonPanelGrid.add(employeeListButton);

        buttonPanelFlow.add(buttonPanelGrid);
        
        // Сборка интерфейса
        mainPanel.add(welcomePanel);
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(buttonPanelFlow);

        return mainPanel;
    }
}