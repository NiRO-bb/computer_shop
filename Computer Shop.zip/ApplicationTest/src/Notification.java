import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Notification extends JDialog {
    public Notification(String exception) {
        super(new JFrame(), "Уведомление", true);

        getContentPane().add(createPanel(exception));
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel(String exception) {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        mainPanel.addKeyListener(listener);

        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        mainPanel.add(new JLabel(exception));
        mainPanel.add(Box.createVerticalStrut(5));
        mainPanel.add(okButton);

        return mainPanel;
    }

    KeyListener listener = new KeyListener() {
        @Override
        public void keyTyped(KeyEvent event) {
            dispose();
        }
        @Override
        public void keyPressed(KeyEvent event) {}
        @Override
        public void keyReleased(KeyEvent event) {}
    };
}
