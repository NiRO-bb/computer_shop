import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SQL {
    // через xampp
    static String URL = "jdbc:mysql://localhost:3306/niro_bb";
    static String dbUsername = "niro_bb", dbPassword = "2034";

    static Connection conn;
    static Statement statement;

    // АВТОРИЗАЦИЯ
    public static boolean checkUsers(String login, String password) throws SQLException {
        boolean flag = false;

        // подключение к бд
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ResultSet data = statement.executeQuery("SELECT * " +
                "FROM users " +
                "WHERE login = '" + login + "' AND password = '" + password + "'");

        while (data.next())
            flag = true;


        conn.close();
        return flag;
    }

    // РЕГИСТРАЦИЯ - проверка логина
    public static boolean isLoginExist(String login) throws SQLException {
        boolean flag = false;

        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ResultSet data = statement.executeQuery("SELECT login FROM users WHERE login = '" + login + "'");

        while (data.next())
            flag = true;

        conn.close();
        return flag;
    }

    // РЕГИСТРАЦИЯ - добавление нового клиента
    public static void createUser(String login, String password, String code) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        statement.executeUpdate("INSERT INTO users(login, password, code) VALUES ('" + login + "', '" + password + "', '"+code+"')");

        conn.close();
    }

    // МЕНЮ - проверка кода
    public static String checkCode(String login) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String code = "none";
        ResultSet data = statement.executeQuery("SELECT login, code FROM users WHERE login = '"+login+"'");

//        while (data.next()) {
//            if (data.getString("login").equals(login)) {
//                return data.getString("code");
//            }
//        }
        while (data.next())
            code = data.getString("code");

        conn.close();
        return code;
    }

    // КАТАЛОГ - получение информации о товарах
    public static ArrayList<String[]> getProductInfo() throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ArrayList<String[]> products = new ArrayList<>();

        ResultSet data = statement.executeQuery("SELECT id, type, model, manufacturer, price FROM product");
        while (data.next()) {
            products.add(new String[]{data.getString("id"), data.getString("type"), data.getString("model"), data.getString("manufacturer"), data.getString("price")});
        }

        conn.close();
        return products;
    }

    // НАЛИЧИЕ ТОВАРА - получение списка магазинов, в которых есть выбранный товар
    public static ArrayList<String> getShopList(String productId) throws SQLException{
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ArrayList<String> shops = new ArrayList<>();

        // получаем данные
        ResultSet data = statement.executeQuery("SELECT `city`, `street`, `building` " +
                "FROM `shop` " +
                "INNER JOIN `product_copy` " +
                "ON `shop`.`id` = `product_copy`.`shop_id` " +
                "WHERE `product_copy`.`product_id` = " + productId);

        // добавляем данные в shops
        while (data.next()){
            String address = data.getString("city") + ", ул. " + data.getString("street") + ", д. " + data.getString("building");
            boolean isShopAdded = false;

            // проверка на наличие магазина в списке
            for (String shop : shops) {
                isShopAdded = false;
                if (shop.equals(address))
                {
                    isShopAdded = true;
                    break;
                }
            }

            // если магазин не был добавлен в список, то добавляем его
            if (!isShopAdded)
                shops.add(address);
        }

        conn.close();
        return shops;
    }

    // ДОБАВЛЕНИЕ ЗАПИСИ О ТОВАРЕ - получение списка товаров
    public static String[] getProductId() throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ArrayList<String> products = new ArrayList<>();

        ResultSet data = statement.executeQuery("SELECT `id` FROM `product`");
        while (data.next())
            products.add(data.getString("id"));

        String[] result = new String[products.size()];
        for (int i = 0; i < products.size(); i++)
            result[i] = products.get(i);

        conn.close();
        return result;
    }

    // ДОБАВЛЕНИЕ ЗАПИСИ О ТОВАРЕ - получение id магазина
    public static String getShopId(String login) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        //String request = "SELECT `shop_id`, `login` FROM `employee` WHERE login = '" + login + "'";
        String request = "SELECT `shop_id` FROM `employee` WHERE login = '" + login + "'";
        ResultSet data = statement.executeQuery(request);

        String shopId = null;

//        while(data.next()) {
//            if (data.getString("login").equals(login)) {
//                shopId = data.getString("shop_id");
//                break;
//            }
//        }
        while (data.next())
            shopId = data.getString("shop_id");

        conn.close();
        return shopId;
    }

    // ДОБАВЛЕНИЕ ЗАПИСИ О ТОВАРЕ - проверка артикула экземпляра
    public static String checkArticleNumber(String articleStart) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        // articleStart - shop_id и product_id
        int Number = 1, maxArticle = 0;
        ArrayList<Integer> articles = new ArrayList<>();

        ResultSet data = statement.executeQuery("SELECT `article` FROM `product_copy`");
        while(data.next()) {
            // проверка на длину
            if (data.getString("article").length() >= articleStart.length()) {
                // если shop_id и product_id совпадают с началом article из бд
                if (data.getString("article").substring(0, articleStart.length()).equals(articleStart)) {
                    articles.add(Integer.parseInt(data.getString("article").substring(articleStart.length())));
                    if (maxArticle < articles.getLast())
                        maxArticle = articles.getLast();
                }
            }
        }

        articles.add(maxArticle + 2);
        boolean isFound;

        while (true) {
            isFound = false;

            // сравниваем все числа с Number
            for (int i = 0; i < articles.size(); i++) {
                if (Number == articles.get(i)) {
                    Number++;
                    isFound = true;
                    break;
                }
            }

            // если нашлось равное число - продолжаем искать, иначе - выходим из цикла
            if (!isFound)
                break;
        }

        conn.close();
        return String.valueOf(Number);
    }

    // ДОБАВЛЕНИЕ ЗАПИСИ О ТОВАРЕ
    public static void addProductCopy(String number, String productId, String shopId) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        statement.executeUpdate("INSERT INTO `product_copy`(`article`, `product_id`, `shop_id`) VALUES ('"+number+"', '"+productId+"', '"+shopId+"')");

        conn.close();
    }

    // ИЗМЕНЕНИЕ ЗАПИСИ О ТОВАРЕ - получение списка артикулов (магазин)
    public static ArrayList<String> getArticleList(String shopId) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ArrayList<String> articles = new ArrayList<>();

        ResultSet data = statement.executeQuery("SELECT `article` FROM `product_copy` WHERE `shop_id`= "+shopId);
        while(data.next()) {
            articles.add(data.getString("article"));
        }

        conn.close();
        return articles;
    }
    // ИЗМЕНЕНИЕ ЗАПИСИ О ТОВАРЕ - получение списка артикулов (магазин + продукт)
    public static ArrayList<String> getArticleList(String shopId, String productId) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ArrayList<String> articles = new ArrayList<>();

        ResultSet data = statement.executeQuery("SELECT `article` FROM `product_copy` WHERE `shop_id`= "+shopId+" AND `product_id`= "+productId);
        while(data.next()) {
            articles.add(data.getString("article"));
        }

        conn.close();
        return articles;
    }

    // УДАЛЕНИЕ ЗАПИСИ О ТОВАРЕ
    public static void deleteArticle(String article) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "DELETE FROM `product_copy` WHERE `article` = '" + article + "'";
        statement.executeUpdate(request);

        conn.close();
    }

    // ИЗМЕНЕНИЕ АРТКУЛА
    public static void updateArticle(String oldArticle, String newArticle) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "UPDATE `product_copy` SET `article` = '" + newArticle + "' WHERE `article` = '" + oldArticle + "'";
        statement.executeUpdate(request);

        conn.close();
    }

    // НОВАЯ ОПЕРАЦИЯ - получение id сотрудника
    public static String getEmployeeId(String login) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String employeeId = null;

        ResultSet data = statement.executeQuery("SELECT `id` FROM `employee` WHERE `login` = '" + login + "'");
        while(data.next()) {
            employeeId = data.getString("id");
        }

        conn.close();
        return employeeId;
    }

    // НОВАЯ ОПЕРАЦИЯ - внести данные об операции
    public static void addTransaction(String type, String shopId, String productId, String amount, String responsible) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "INSERT INTO `transaction`(`type`, `shop_id`, `product_id`, `amount`, `responsible`) VALUES ('"+type+"','"+shopId+"','"+productId+"','"+Integer.parseInt(amount)+"','"+responsible+"')";
        statement.executeUpdate(request);

        conn.close();
    }

    // ИСТОРИЯ ОПЕРАЦИЙ для конкретного магазина
    public static ArrayList<String[]> getTransactionList(String shopId) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();
        ArrayList<String[]> transactions = new ArrayList<>();

        ResultSet data = statement.executeQuery("SELECT `id`, `type`, `product_id`, `amount`, `responsible` FROM `transaction` WHERE `shop_id` = '"+shopId+"'");
        while(data.next()) {
            transactions.add(new String[]{data.getString("id"), data.getString("type"), data.getString("product_id"), data.getString("amount"), data.getString("responsible")});
        }

        conn.close();
        return transactions;
    }

    // ДОБАВЛЕНИЕ НОВОГО ТОВАРА В КАТАЛОГ
    public static void addProduct(int id, String type, String model, String manufacturer, double price) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "INSERT INTO `product`(`id`, `type`, `model`, `manufacturer`, `price`) VALUES ('"+id+"','"+type+"','"+model+"','"+manufacturer+"','"+price+"')";
        statement.executeUpdate(request);

        conn.close();
    }

    // ИЗМЕНЕНИЕ ТОВАРА В КАТАЛОГЕ
    public static void editProduct(int id, String type, String model, String manufacturer, double price) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "UPDATE `product` SET `id`='"+id+"', `type`='"+type+"', `model`='"+model+"', `manufacturer`='"+manufacturer+"', `price`='"+price+"' WHERE `id` = '"+id+"'";
        statement.executeUpdate(request);

        conn.close();
    }

    // УДАЛЕНИЕ ТОВАРА ИЗ КАТАЛОГА
    public static void removeProduct(int id) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "DELETE FROM `product` WHERE `id` = '"+id+"'";
        statement.executeUpdate(request);

        conn.close();
    }

    // ДОБАВЛЕНИЕ НОВОГО МАГАЗИНА
    public static void addShop(String id, String city, String street, int building) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "INSERT INTO `shop`(`id`, `city`, `street`, `building`) VALUES ('"+id+"','"+city+"','"+street+"','"+building+"')";
        statement.executeUpdate(request);

        conn.close();
    }

    // ПОЛУЧЕНИЕ ИНФОРМАЦИИ О МАГАЗИНАХ
    public static ArrayList<String[]> getShopInfo() throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ArrayList<String[]> shops = new ArrayList<>();

        ResultSet data = statement.executeQuery("SELECT id, city, street, building FROM shop");
        while (data.next()) {
            shops.add(new String[]{data.getString("id"), data.getString("city"), data.getString("street"), data.getString("building")});
        }

        conn.close();
        return shops;
    }

    // УДАЛЕНИЕ МАГАЗИНА
    public static void removeShop(String id) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "DELETE FROM `shop` WHERE `id` = '"+id+"'";
        statement.executeUpdate(request);

        conn.close();
    }

    // ИЗМЕНЕНИЕ МАГАЗИНА
    public static void editShop(String id, String city, String street, int building) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "UPDATE `shop` SET `id`='"+id+"', `city`='"+city+"', `street`='"+street+"', `building`='"+building+"', WHERE `id` = '"+id+"'";
        statement.executeUpdate(request);

        conn.close();
    }

    // ДОБАВЛЕНИЕ ЗАПИСИ ОБ ОПЕРАЦИИ - получение списка магазинов
    public static String[] getShopId() throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ArrayList<String> shops = new ArrayList<>();

        ResultSet data = statement.executeQuery("SELECT `id` FROM `shop`");
        while (data.next())
            shops.add(data.getString("id"));

        String[] result = new String[shops.size()];
        for (int i = 0; i < shops.size(); i++)
            result[i] = shops.get(i);

        conn.close();
        return result;
    }

    // ИСТОРИЯ ОПЕРАЦИЙ
    public static ArrayList<String[]> getTransactionList() throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();
        ArrayList<String[]> transactions = new ArrayList<>();

        ResultSet data = statement.executeQuery("SELECT `id`, `type`, `shop_id`, `product_id`, `amount`, `responsible` FROM `transaction`");
        while(data.next()) {
            transactions.add(new String[] {data.getString("id"), data.getString("type"), data.getString("shop_id"), data.getString("product_id"), data.getString("amount"), data.getString("responsible")});
        }

        conn.close();
        return transactions;
    }

    // УДАЛЕНИЕ ОПЕРАЦИИ
    public static void removeTransaction(int id) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();
        String request = "DELETE FROM `transaction` WHERE `id` = '"+id+"'";

        statement.executeUpdate(request);

        conn.close();
    }

    // ДОБАВЛЕНИЕ НОВОГО сотрудника
    public static void addEmployee(String id, String shop_id, String full_name, String post, int salary, String login) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "INSERT INTO `employee`(`id`, `shop_id`, `full_name`, `post`, `salary`, `login`) VALUES ('"+id+"','"+shop_id+"','"+full_name+"','"+post+"','"+salary+"','"+login+"')";
        statement.executeUpdate(request);

        conn.close();
    }

    // ПОЛУЧЕНИЕ ИНФОРМАЦИИ О СОТРУДНИКАХ
    public static ArrayList<String[]> getEmployeeInfo() throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ArrayList<String[]> employees = new ArrayList<>();

        ResultSet data = statement.executeQuery("SELECT `id`, `shop_id`, `full_name`, `post`, `salary`, `login` FROM `employee`");
        while (data.next()) {
            employees.add(new String[]{data.getString("id"), data.getString("shop_id"), data.getString("full_name"), data.getString("post"), data.getString("salary"), data.getString("login")});
        }

        conn.close();
        return employees;
    }

    // УДАЛЕНИЕ СОТРУДНИКА
    public static void removeEmployee(String id) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();
        String request = "DELETE FROM `employee` WHERE `id` = '"+id+"'";

        statement.executeUpdate(request);

        conn.close();
    }

    // ИЗМЕНЕНИЕ ИНФОРМАЦИИ О СОТРУДНИКЕ
    public static void editEmployee(String id, String shop_id, String full_name, String post, int salary, String login) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        String request = "UPDATE `employee` SET `id`='"+id+"', `shop_id`='"+shop_id+"', `full_name`='"+full_name+"', `post`='"+post+"', `salary`='"+salary+"', `login`='"+login+"' WHERE `id` = '"+id+"'";
        statement.executeUpdate(request);

        conn.close();
    }

    // ПОЛУЧЕНИЕ КОДА ДОСТУПА ПОЛЬЗОВАТЕЛЯ
    public static String getCode(String login) throws SQLException {
        conn = DriverManager.getConnection(URL, dbUsername, dbPassword);
        statement = conn.createStatement();

        ResultSet data = statement.executeQuery("SELECT `code` FROM `users` WHERE `login` = '"+login+"'");

        String code = null;
        while(data.next()) {
            code = data.getString("code");
        }

        conn.close();
        return code;
    }
}