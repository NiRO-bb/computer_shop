import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class ShopMenu extends JDialog {
    private String login, shopId;

    public ShopMenu(String login, String shopId) {
        super(new JFrame(), "Меню магазина");

        this.login = login;
        this.shopId = shopId;

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // buttons
        JButton addCopy = new JButton("Добавить запись");
        addCopy.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddProductCopy(login, shopId);
            }
        });
        JButton editCopy = new JButton("Изменить запись");
        editCopy.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new EditProductCopy(login, shopId);
                dispose();
            }
        });
        JButton exitButton = new JButton("Назад");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ShopList(login);
                dispose();
            }
        });

        // Сборка интерфейса
        mainPanel.add(new JLabel("Работа с ассортиментом магазина:"));
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(addCopy);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(editCopy);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(exitButton);

        return mainPanel;
    }
}
