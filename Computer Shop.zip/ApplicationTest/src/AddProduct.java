import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddProduct extends JDialog {
    private String[] productInfo = new String[] {"", "", "", "", ""};

    public AddProduct() {
        super(new JFrame(), "Добавление товара");
        init();
    }

    public AddProduct(String[] productInfo) {
        super(new JFrame(), "Редактирование товара");

        this.productInfo = productInfo;

        init();
    }

    private void init() {
        getContentPane().add(createPanel());
        pack();

        setResizable(false);
        setVisible(true);
    }

    private JPanel createPanel() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 20));

        // info
        JPanel infoPanel = new JPanel();
        infoPanel.add(new JLabel("Введите данные товара"));

        // id
        JPanel idPanel = new JPanel();
        idPanel.setLayout(new BoxLayout(idPanel, BoxLayout.X_AXIS));
        JTextField idField = new JTextField(10);
        idField.setText(productInfo[0]);

        idPanel.add(new JLabel("ID товара: "));
        idPanel.add(idField);

        // type
        JPanel typePanel = new JPanel();
        typePanel.setLayout(new BoxLayout(typePanel, BoxLayout.X_AXIS));
        JTextField typeField = new JTextField(20);
        typeField.setText(productInfo[1]);

        typePanel.add(new JLabel("Тип товара: "));
        typePanel.add(typeField);

        // model
        JPanel modelPanel = new JPanel();
        modelPanel.setLayout(new BoxLayout(modelPanel, BoxLayout.X_AXIS));
        JTextField modelField = new JTextField(20);
        modelField.setText(productInfo[2]);

        modelPanel.add(new JLabel("Модель: "));
        modelPanel.add(modelField);

        // manufacturer
        JPanel manufacturerPanel = new JPanel();
        manufacturerPanel.setLayout(new BoxLayout(manufacturerPanel, BoxLayout.X_AXIS));
        JTextField manufacturerField = new JTextField(20);
        manufacturerField.setText(productInfo[3]);

        manufacturerPanel.add(new JLabel("Производитель: "));
        manufacturerPanel.add(manufacturerField);

        // price
        JPanel pricePanel = new JPanel();
        pricePanel.setLayout(new BoxLayout(pricePanel, BoxLayout.X_AXIS));
        JTextField priceField = new JTextField(10);
        priceField.setText(productInfo[4]);

        pricePanel.add(new JLabel("Цена: "));
        pricePanel.add(priceField);

        // buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));

        String buttonText;
        if (productInfo[0].equals(""))
            buttonText = "Добавить товар";
        else
            buttonText = "Изменить";

        JButton addButton = new JButton(buttonText);
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (productInfo[0].equals(""))
                    {
                        SQL.addProduct(Integer.parseInt(idField.getText()),
                                typeField.getText(),
                                modelField.getText(),
                                manufacturerField.getText(),
                                Double.parseDouble(priceField.getText()));
                        new Notification("Товар успешно добавлен в каталог");
                    } else {
                        SQL.editProduct(Integer.parseInt(idField.getText()),
                                typeField.getText(),
                                modelField.getText(),
                                manufacturerField.getText(),
                                Double.parseDouble(priceField.getText()));
                        new Notification("Информация о товаре успешно изменена");
                    }
                    dispose();
                } catch (Exception exception) {
                    new Notification(exception.getMessage());
                }
            }
        });

        buttonPanel.add(addButton);

        // сборка интерфейса
        mainPanel.add(infoPanel);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(idPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(typePanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(modelPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(manufacturerPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(pricePanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(buttonPanel);

        return mainPanel;
    }
}
